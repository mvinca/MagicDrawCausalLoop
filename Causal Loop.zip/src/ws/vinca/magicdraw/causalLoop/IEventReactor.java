package ws.vinca.magicdraw.causalLoop;

public interface IEventReactor {
	void React( ICausalEvent e );
}
